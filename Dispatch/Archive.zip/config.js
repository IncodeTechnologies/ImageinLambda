var config = {};

config.redis = {};
config.redis.host = 'nodelambdatest.14uibc.0001.usw2.cache.amazonaws.com';
config.redis.port = 6379;
config.redis.usersQueue = 'users';

module.exports = config;